import java.io.Serializable;

public class Filial implements Serializable{

}
