import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TesteX
{
    /**
     * Construtor default para a classe de teste TesteX
     */
    public TesteX(){
        
    }
}
